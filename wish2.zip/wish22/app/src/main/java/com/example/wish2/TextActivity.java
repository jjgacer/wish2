package com.example.wish2;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

public class TextActivity extends AppCompatActivity {

    private static String wishtext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wish_layout);

        SharedPreferences shared = getApplicationContext().getSharedPreferences("wish please", Context.MODE_PRIVATE);


        Button bt = findViewById(R.id.let_me_home);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("wish_key", wishtext);
                startActivity(intent);
            }
        });
    }

    public class wishBox extends DialogFragment {
        @Override
        public Dialog onCreateDialog(Bundle savedInstance){
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            EditText input = (EditText)findViewById(R.id.wish_input);
            builder.setView(input);
            wishtext = input.getText().toString();
            return builder.create();
        }
    }

}
