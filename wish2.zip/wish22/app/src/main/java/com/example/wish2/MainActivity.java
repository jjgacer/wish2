package com.example.wish2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity {

    //static ArrayList<String> wishing = new ArrayList<>();
    //static ArrayAdapter adapter;
//    String[] aray;
    private EditText w;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //ListView list = (ListView)findViewById(R.id.wishlist);
        //w = findViewById(R.id.wish_input);

        Intent intent = getIntent();
        String lastWish = intent.getStringExtra("wish_key");
        TextView text = (TextView)findViewById(R.id.wishtext);
        text.setText(lastWish);
        //list.addHeaderView(text);

//        list.setAdapter(adapter);
//        SharedPreferences shared = getApplicationContext().getSharedPreferences("wish", Context.MODE_PRIVATE);
//        HashSet<String> set = (HashSet<String>) shared.getStringSet("wish", null);
//        if(set==null){
//            wishing.add("example wish");
//        } else {
//            wishing = new ArrayList(set);
//        }
//
//        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, wishing);
//        list.setAdapter(adapter);
//        list.setOnClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void OnItemClickListener(AdapterView<?> adapter, View view, int i, long l){
//                Intent intent = new Intent(getApplicationContext(), TextActivity.class);
//                intent.putExtra("wishID", i);
//                startActivity(intent);
//            }
//        });


        Button button = (Button)findViewById(R.id.wish_button);
        button.setOnClickListener(new View.OnClickListener() {
            Intent intent = new Intent(MainActivity.this, TextActivity.class);
            @Override
            public void onClick(View view) {
                startActivity(intent);
//                DialogFragment fragment = new TextActivity.wishBox();
//                fragment.show(getSupportFragmentManager(), "wish_tag");
            }
        });


    }



}